import torch
import math

class AdamCY(torch.optim.Optimizer):
    def __init__(self, params, lr=1e-3, min_lr=1e-4, max_lr=0.1, betas=(0.9, 0.999), eps=1e-8, weight_decay=0):
        if not 0.0 <= lr:
            raise ValueError("Invalid learning rate: {}".format(lr))
        if not 0.0 <= eps:
            raise ValueError("Invalid epsilon value: {}".format(eps))
        if not 0.0 <= betas[0] < 1.0:
            raise ValueError("Invalid beta parameter at index 0: {}".format(betas[0]))
        if not 0.0 <= betas[1] < 1.0:
            raise ValueError("Invalid beta parameter at index 1: {}".format(betas[1]))

        defaults = dict(lr=lr, min_lr=min_lr, max_lr=max_lr, betas=betas, eps=eps, weight_decay=weight_decay)
        super(AdamCY, self).__init__(params, defaults)

        # 将学习率设置为一个变量lr，并保存为实例变量self.lr
        self.lr = lr

    def __setstate__(self, state):
        super(AdamCY, self).__setstate__(state)

    def step(self, closure=None):
        loss = None
        if closure is not None:
            loss = closure()
        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue
                grad = p.grad.data
                if grad.is_sparse:
                    raise RuntimeError('Adam does not support sparse gradients, please consider SparseAdam instead')
                # amsgrad = group['amsgrad']
                state = self.state[p] # 之前的step累计数据
                # State initialization
                if len(state) == 0:
                    state['step'] = 0
                    state['exp_avg'] = torch.zeros_like(p.data) # [batch, seq]
                    state['exp_avg_sq'] = torch.zeros_like(p.data)
                    state['buf'] = torch.zeros_like(p.data)
                buf = torch.zeros_like(p.data)
                    # if amsgrad:
                    #     # Maintains max of all exp. moving avg. of sq. grad. values
                    #     state['max_exp_avg_sq'] = torch.zeros_like(p.data)
                exp_avg, exp_avg_sq = state['exp_avg'], state['exp_avg_sq'] # 上次的r与s
                # if amsgrad:
                # # asmgrad优化方法是针对Adam的改进，通过添加额外的约束，使学习率始终为正值。
                #     max_exp_avg_sq = state['max_exp_avg_sq']
                beta1, beta2 = group['betas']
                state['step'] += 1
                bias_correction1 = 1 - beta1 ** state['step']
                bias_correction2 = 1 - beta2 ** state['step']
                if group['weight_decay'] != 0:  # 进行权重衰减(实际是L2正则化）
                	# 6. grad(t)=grad(t-1)+ weight*p(t-1)
                    grad.add_(group['weight_decay'], p.data)
                # if state['step']== 1:
                #     exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
                #     buf=exp_avg
                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1) #计算m(t): m(t)=beta_1*m(t-1)+(1-beta_1)*grad
                buf[buf == 0]= 1e-7
                print("exp_avg---:", len(exp_avg))
                momentum_ratio = exp_avg / buf
                momentum_ratio[momentum_ratio < 0] = momentum_ratio.min()
                ratio_norm = 25*(momentum_ratio - momentum_ratio.min())/ (momentum_ratio.max() - momentum_ratio.min() + 1e-7)
                # print("state['step']------------",state['step'])
                print("buf------------------:", buf)
                print("exp_avg---------------:", exp_avg)
                print("ratio---------------:", momentum_ratio)
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2) #v(t)= beta_2*v(t-1)+(1-beta_2)*grad^2
                # if amsgrad:
                #     # 迭代改变max_exp_avg_sq的值（取最大值），传到下一次，保留之前的梯度信息。
                #     torch.max(max_exp_avg_sq, exp_avg_sq, out=max_exp_avg_sq)
                #     # Use the max. for normalizing running avg. of gradient
                #     denom = (max_exp_avg_sq.sqrt() / math.sqrt(bias_correction2)).add_(group['eps'])
                # else:
                	# 计算sqrt(v(t))+epsilon
                # sqrt(v(t))+eps = denom = sqrt(v(t))/sqrt(1-beta_2^t)+eps
                # 更新缓存区中的动量值
                buf = exp_avg.clone()

                denom = (exp_avg_sq.sqrt() / math.sqrt(bias_correction2)).add_(group['eps'])
				# step_size=lr/bias_correction1=lr/(1-beta_1^t)
                step_size = group['lr'] / bias_correction1
				#p(t)=p(t-1)-step_size*m(t)/denom
                if state['step'] == 1:
                    p.data.addcdiv_(exp_avg , denom, value=-step_size)
                else:
                    p.data.addcdiv_(exp_avg * ratio_norm, denom, value=-step_size)

        return loss
