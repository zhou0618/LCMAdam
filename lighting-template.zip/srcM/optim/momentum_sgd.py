# import math
# import torch
# import wandb
# class CYAdam(torch.optim.Optimizer):
#     def __init__(self, params, lr=1e-3, betas=0.9, eps=1e-8, weight_decay=0):
#         if not 0.0 <= lr:
#             raise ValueError("Invalid learning rate: {}".format(lr))
#         if not 0.0 <= eps:
#             raise ValueError("Invalid epsilon value: {}".format(eps))
#         if not 0.0 <= betas < 1.0:
#             raise ValueError("Invalid beta parameter at index 0: {}".format(betas))
#         defaults = dict(lr=lr, betas=betas, eps=eps,weight_decay=weight_decay)
#         super(CYAdam, self).__init__(params, defaults)
#         self.lr = lr
#     def step(self, closure=None):
#         """Performs a single optimization step.
#
#         Arguments:
#             closure (callable, optional): A closure that reevaluates the model
#                 and returns the loss.
#         """
#         loss = None
#         if closure is not None:
#             loss = closure()
#
#         for group in self.param_groups:
#             for p in group['params']:
#                 if p.grad is None:
#                     continue
#                 grad = p.grad.data
#                 if grad.is_sparse:
#                     raise RuntimeError('Adam does not support sparse gradients, please consider SparseAdam instead')
#
#                 state = self.state[p] # 之前的step累计数据
#
#                 # State initialization
#                 if len(state) == 0:
#                     state['step'] = 0
#                     # Exponential moving average of gradient values
#                     state['exp_avg'] = torch.zeros_like(p.data) # [batch, seq]
#
#                 exp_avg = state['exp_avg'] # 上次的r与s
#                 beta1 = group['betas']
#
#                 state['step'] += 1
#                 bias_correction1 = 1 - beta1 ** state['step']
#                 if group['weight_decay'] != 0:
#                     # 进行权重衰减(实际是L2正则化）
#                 	# 6. grad(t)=grad(t-1)+ weight*p(t-1)
#                     grad.add_(group['weight_decay'], p.data)
#
#                 # Decay the first and second moment running average coefficient
#                 # 7.计算m(t): m(t)=beta_1*m(t-1)+(1-beta_1)*grad
#                 exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
#                 	# 计算sqrt(v(t))+epsilon
#                 	# sqrt(v(t))+eps = denom = sqrt(v(t))/sqrt(1-beta_2^t)+eps
# 				# step_size=lr/bias_correction1=lr/(1-beta_1^t)
#                 wandb.log({
#                     'lr': group['lr'],
#                 })
#                 step_size = group['lr'] / bias_correction1
#                 step_size = torch.tensor(step_size)
# 				#p(t)=p(t-1)-step_size*m(t)/denom
#                 p.data.addcdiv_(-step_size, exp_avg)
#
#         return loss
import torch
from torch.optim import Optimizer
# import wandb
import numpy as np
class CYADAM(Optimizer):
    def __init__(self, params, lr=1e-3, momentum=0.9, dampening=0, weight_decay=0, nesterov=False):
        if lr < 0.0:
            raise ValueError("Invalid learning rate: {}".format(lr))
        if momentum < 0.0:
            raise ValueError("Invalid momentum value: {}".format(momentum))
        if weight_decay < 0.0:
            raise ValueError("Invalid weight_decay value: {}".format(weight_decay))

        defaults = dict(lr=lr, momentum=momentum, dampening=dampening,
                        weight_decay=weight_decay, nesterov=nesterov)
        super(CYADAM, self).__init__(params, defaults)

    def step(self, closure=None):
        """Performs a single optimization step."""
        loss = None
        if closure is not None:
            loss = closure()
        for group in self.param_groups:
            weight_decay = group['weight_decay']
            momentum = group['momentum']
            dampening = group['dampening']
            nesterov = group['nesterov']
            lr = group['lr']
            for p in group['params']:
                if p.grad is None:
                    continue
                d_p = p.grad.data
                if weight_decay != 0:
                    d_p.add_(weight_decay, p.data)
                if momentum != 0:
                    param_state = self.state[p]
                    if 'momentum_buffer' not in param_state:
                        buf = param_state['momentum_buffer'] = torch.clone(d_p).detach()
                    else:
                        buf = param_state['momentum_buffer']
                        buf.mul_(momentum).add_(d_p,alpha=1 - dampening)

                    d_p.add(buf, alpha=momentum)
                    buf[buf == 0] = 1e-7
                    # if nesterov:
                    #     d_p = d_p.add(momentum, buf)
                    # else:
                    #     d_p = buf

                    # ratio = d_p/buf *abs(buf[0,0])
                    ratio = d_p/buf
                    ratio[ratio<0]=ratio.min()
                    ratio_norm = ((ratio - ratio.min()) / (ratio.max() - ratio.min()+ 1e-7))*90

                    # print("buf------------", buf)
                    # print("d_p------------", d_p)
                    # # print("ratio------------", ratio)
                    # print("ratio_norm------------", ratio_norm)
                # wandb.log({
                #     'lr': group['lr'],
                # })
                p.data.add_(d_p*ratio_norm, alpha=-lr)
                # p.data.add_(d_p, alpha=-lr)

        return loss


